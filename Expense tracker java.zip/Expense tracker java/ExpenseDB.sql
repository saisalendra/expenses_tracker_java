CREATE DATABASE ExpenseDB;
USE ExpenseDB;
CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50),
    Password VARCHAR(50)
);
CREATE TABLE Expenses (
    ExpenseID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Category VARCHAR(50),
    Amount DOUBLE,
    Date DATE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

CREATE DATABASE ExpenseDB;
USE ExpenseDB;


CREATE TABLE Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(50),
    Password VARCHAR(50)
);
DROP TABLE Expenses;
CREATE TABLE Expenses (
    ExpenseID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    Category VARCHAR(50),
    Amount DOUBLE,
    Date DATE,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
