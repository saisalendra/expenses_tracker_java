import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class AddExpense extends JFrame implements ActionListener {
    JComboBox<String> categoryBox;
    JTextField amountField, dateField;
    JButton saveButton;

    public AddExpense() {
        setTitle("Add Expense");
        setLayout(null);

        JLabel categoryLabel = new JLabel("Category:");
        categoryLabel.setBounds(50, 50, 100, 30);
        add(categoryLabel);

        categoryBox = new JComboBox<>(new String[]{"Food", "Transport", "Utilities"});
        categoryBox.setBounds(150, 50, 200, 30);
        add(categoryBox);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(50, 100, 100, 30);
        add(amountLabel);

        amountField = new JTextField();
        amountField.setBounds(150, 100, 200, 30);
        add(amountField);

        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setBounds(50, 150, 150, 30);
        add(dateLabel);

        dateField = new JTextField();
        dateField.setBounds(200, 150, 150, 30);
        add(dateField);

        saveButton = new JButton("Save");
        saveButton.setBounds(150, 200, 100, 30);
        saveButton.addActionListener(this);
        add(saveButton);

        setSize(450, 300);
        setLocation(400, 200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String category = (String) categoryBox.getSelectedItem();
        double amount = Double.parseDouble(amountField.getText());
        String date = dateField.getText();

        try {
            Connection con = DatabaseConnection.getConnection();
            String query = "INSERT INTO Expenses (UserID, Category, Amount, Date) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            // Assuming UserID is available (e.g., through login session)
            pst.setInt(1, 1); // replace with actual user ID
            pst.setString(2, category);
            pst.setDouble(3, amount);
            pst.setString(4, date);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Expense added successfully!");
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}