import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class RegistrationScreen extends JFrame implements ActionListener {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton registerButton;

    public RegistrationScreen() {
        setTitle("Register");
        setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 50, 100, 30);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(150, 50, 200, 30);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 100, 100, 30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 100, 200, 30);
        add(passwordField);

        registerButton = new JButton("Register");
        registerButton.setBounds(150, 150, 100, 30);
        registerButton.addActionListener(this);
        add(registerButton);

        setSize(450, 300);
        setLocation(400, 200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText();
        String password = String.valueOf(passwordField.getPassword());

        try {
            Connection con = DatabaseConnection.getConnection();
            String query = "INSERT INTO Users (Username, Password) VALUES (?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, username);
            pst.setString(2, password);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "User registered successfully!");
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}


