import javax.swing.*;
import java.sql.*;

public class ExpenseSummary extends JFrame {
    JTextArea summaryArea;

    public ExpenseSummary() {
        setTitle("Expense Summary");
        setLayout(null);

        summaryArea = new JTextArea();
        summaryArea.setBounds(50, 20, 400, 400);
        summaryArea.setEditable(false);
        add(summaryArea);

        loadSummary();

        setSize(500, 450);
        setLocation(400, 200);
        setVisible(true);
    }

    private void loadSummary() {
        try {
            Connection con = DatabaseConnection.getConnection();
            String query = "SELECT Category, SUM(Amount) as TotalAmount FROM Expenses GROUP BY Category";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            StringBuilder summary = new StringBuilder("Expense Summary:\n\n");
            while (rs.next()) {
                String category = rs.getString("Category");
                double totalAmount = rs.getDouble("TotalAmount");
                summary.append(category).append(": ").append(totalAmount).append("\n");
            }
            summaryArea.setText(summary.toString());
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}