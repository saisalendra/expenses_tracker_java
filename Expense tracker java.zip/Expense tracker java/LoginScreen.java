// import javax.swing.*;
// import java.awt.event.*;
// import java.sql.*;

// public class LoginScreen extends JFrame implements ActionListener {
//     JTextField usernameField;
//     JPasswordField passwordField;
//     JButton loginButton, registerButton;

//     public LoginScreen() {
//         setTitle("Login");
//         setLayout(null);

//         JLabel usernameLabel = new JLabel("Username:");
//         usernameLabel.setBounds(50, 50, 100, 30);
//         add(usernameLabel);

//         usernameField = new JTextField();
//         usernameField.setBounds(150, 50, 200, 30);
//         add(usernameField);

//         JLabel passwordLabel = new JLabel("Password:");
//         passwordLabel.setBounds(50, 100, 100, 30);
//         add(passwordLabel);

//         passwordField = new JPasswordField();
//         passwordField.setBounds(150, 100, 200, 30);
//         add(passwordField);

//         loginButton = new JButton("Login");
//         loginButton.setBounds(150, 150, 100, 30);
//         loginButton.addActionListener(this);
//         add(loginButton);

//         registerButton = new JButton("Register");
//         registerButton.setBounds(250, 150, 100, 30);
//         registerButton.addActionListener(this);
//         add(registerButton);

//         setSize(450, 300);
//         setLocation(400, 200);
//         setVisible(true);
//     }

//     public void actionPerformed(ActionEvent e) {
//         if (e.getSource() == loginButton) {
//             String username = usernameField.getText();
//             String password = String.valueOf(passwordField.getPassword());

//             try {
//                 Connection con = DatabaseConnection.getConnection();
//                 String query = "SELECT * FROM Users WHERE Username=? AND Password=?";
//                 PreparedStatement pst = con.prepareStatement(query);
//                 pst.setString(1, username);
//                 pst.setString(2, password);

//                 ResultSet rs = pst.executeQuery();
//                 if (rs.next()) {
//                     JOptionPane.showMessageDialog(null, "Login Successful!");
//                     // Proceed to main screen
//                 } else {
//                     JOptionPane.showMessageDialog(null, "Invalid credentials.");
//                 }
//                 con.close();
//             } catch (Exception ex) {
//                 ex.printStackTrace();
//             }
//         } else if (e.getSource() == registerButton) {
//             new RegistrationScreen();
//         }
//     }
// }
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class LoginScreen extends JFrame implements ActionListener {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, registerButton;

    public LoginScreen() {
        setTitle("Login");
        setLayout(null);

        // Username Label and Field
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(50, 50, 100, 30);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(150, 50, 200, 30);
        add(usernameField);

        // Password Label and Field
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 100, 100, 30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 100, 200, 30);
        add(passwordField);

        // Login Button
        loginButton = new JButton("Login");
        loginButton.setBounds(150, 150, 100, 30);
        loginButton.addActionListener(this);
        add(loginButton);

        // Register Button
        registerButton = new JButton("Register");
        registerButton.setBounds(250, 150, 100, 30);
        registerButton.addActionListener(this);
        add(registerButton);

        // Frame Settings
        setSize(450, 300);
        setLocation(400, 200);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String username = usernameField.getText();
            String password = String.valueOf(passwordField.getPassword());

            try {
                // Get database connection
                Connection con = DatabaseConnection.getConnection();
                String query = "SELECT * FROM Users WHERE Username=? AND Password=?";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, username);
                pst.setString(2, password);

                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");

                    // After successful login, close the login window and open main screen
                    dispose();  // Close login screen
                    new ExpenseCalculatorMain();  // Open main screen

                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credentials.");
                }
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error connecting to database.");
            }
        } else if (e.getSource() == registerButton) {
            // Open registration screen
            new RegistrationScreen();
        }
    }

    public static void main(String[] args) {
        new LoginScreen();  // Start the login screen when the program runs
    }
}



//java -cp ".;C:\Users\sai\Desktop\java project T\mysql-connector-j-9.1.0.jar" LoginScreen   