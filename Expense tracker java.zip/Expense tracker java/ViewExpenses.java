import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class ViewExpenses extends JFrame implements ActionListener {
    JTable table;
    JComboBox<String> categoryFilter;
    JTextField dateFilter;
    JButton filterButton, refreshButton;

    public ViewExpenses() {
        setTitle("View Expenses");
        setLayout(null);

        JLabel categoryLabel = new JLabel("Category:");
        categoryLabel.setBounds(50, 20, 100, 30);
        add(categoryLabel);

        categoryFilter = new JComboBox<>(new String[]{"All", "Food", "Transport", "Utilities"});
        categoryFilter.setBounds(150, 20, 150, 30);
        add(categoryFilter);

        JLabel dateLabel = new JLabel("Date (YYYY-MM):");
        dateLabel.setBounds(50, 60, 100, 30);
        add(dateLabel);

        dateFilter = new JTextField();
        dateFilter.setBounds(150, 60, 150, 30);
        add(dateFilter);

        filterButton = new JButton("Filter");
        filterButton.setBounds(320, 20, 100, 30);
        filterButton.addActionListener(this);
        add(filterButton);

        refreshButton = new JButton("Refresh");
        refreshButton.setBounds(320, 60, 100, 30);
        refreshButton.addActionListener(this);
        add(refreshButton);

        table = new JTable();
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(50, 100, 500, 300);
        add(sp);

        loadExpenses();
        
        setSize(600, 450);
        setLocation(400, 200);
        setVisible(true);
    }

    private void loadExpenses() {
        try {
            Connection con = DatabaseConnection.getConnection();
            String query = "SELECT * FROM Expenses";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Category", "Amount", "Date"}, 0);
            while (rs.next()) {
                int id = rs.getInt("ExpenseID");
                String category = rs.getString("Category");
                double amount = rs.getDouble("Amount");
                String date = rs.getString("Date");
                model.addRow(new Object[]{id, category, amount, date});
            }
            table.setModel(model);

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == filterButton) {
            String selectedCategory = (String) categoryFilter.getSelectedItem();
            String date = dateFilter.getText();

            try {
                Connection con = DatabaseConnection.getConnection();
                String query = "SELECT * FROM Expenses WHERE 1=1";
                
                if (!selectedCategory.equals("All")) {
                    query += " AND Category=?";
                }
                if (!date.isEmpty()) {
                    query += " AND Date LIKE ?";
                }
                
                PreparedStatement pst = con.prepareStatement(query);
                int paramIndex = 1;

                if (!selectedCategory.equals("All")) {
                    pst.setString(paramIndex++, selectedCategory);
                }
                if (!date.isEmpty()) {
                    pst.setString(paramIndex, date + "%");
                }

                ResultSet rs = pst.executeQuery();
                DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Category", "Amount", "Date"}, 0);

                while (rs.next()) {
                    int id = rs.getInt("ExpenseID");
                    String category = rs.getString("Category");
                    double amount = rs.getDouble("Amount");
                    String expenseDate = rs.getString("Date");
                    model.addRow(new Object[]{id, category, amount, expenseDate});
                }
                table.setModel(model);
                con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == refreshButton) {
            loadExpenses();
        }
    }
}
