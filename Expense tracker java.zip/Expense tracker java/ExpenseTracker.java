import java.sql.Connection;
import java.sql.SQLException;

public class ExpenseTracker {
    public static void main(String[] args) {
        System.out.println("Welcome to Expense Tracker!");

        try {
            Connection conn = DatabaseConnection.getConnection();
            System.out.println("✅ Database connected successfully!");
            conn.close();
        } catch (SQLException e) {
            System.out.println("❌ Database connection error: " + e.getMessage());
        }
    }
}
