import javax.swing.*;
import java.awt.event.*;

public class ExpenseCalculatorMain extends JFrame implements ActionListener {
    JButton addExpenseButton, viewExpensesButton, generateReportButton, summaryButton;

    public ExpenseCalculatorMain() {
        setTitle("Expense Calculator Main Menu");
        setLayout(null);

        addExpenseButton = new JButton("Add Expense");
        addExpenseButton.setBounds(50, 50, 150, 30);
        addExpenseButton.addActionListener(this);
        add(addExpenseButton);

        viewExpensesButton = new JButton("View Expenses");
        viewExpensesButton.setBounds(50, 100, 150, 30);
        viewExpensesButton.addActionListener(this);
        add(viewExpensesButton);

        generateReportButton = new JButton("Generate Report");
        generateReportButton.setBounds(50, 150, 150, 30);
        generateReportButton.addActionListener(this);
        add(generateReportButton);

        summaryButton = new JButton("Expense Summary");
        summaryButton.setBounds(50, 200, 150, 30);
        summaryButton.addActionListener(this);
        add(summaryButton);

        setSize(300, 300);
        setLocation(400, 200);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addExpenseButton) {
            new AddExpense();
        } else if (e.getSource() == viewExpensesButton) {
            new ViewExpenses();
        } else if (e.getSource() == generateReportButton) {
            new GenerateReport();
        } else if (e.getSource() == summaryButton) {
            new ExpenseSummary();
        }
    }

    public static void main(String[] args) {
        new ExpenseCalculatorMain();
    }
}