import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class GenerateReport extends JFrame implements ActionListener {
    JTextField monthField;
    JTextArea reportArea;
    JButton generateButton;

    public GenerateReport() {
        setTitle("Generate Monthly Report");
        setLayout(null);

        JLabel monthLabel = new JLabel("Enter Month (YYYY-MM):");
        monthLabel.setBounds(50, 20, 150, 30);
        add(monthLabel);

        monthField = new JTextField();
        monthField.setBounds(200, 20, 150, 30);
        add(monthField);

        generateButton = new JButton("Generate");
        generateButton.setBounds(200, 60, 150, 30);
        generateButton.addActionListener(this);
        add(generateButton);

        reportArea = new JTextArea();
        reportArea.setBounds(50, 100, 400, 300);
        reportArea.setEditable(false);
        add(reportArea);

        setSize(500, 450);
        setLocation(400, 200);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String month = monthField.getText();
        if (month.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter a month.");
            return;
        }

        try {
            Connection con = DatabaseConnection.getConnection();
            String query = "SELECT Category, SUM(Amount) as TotalAmount FROM Expenses WHERE Date LIKE ? GROUP BY Category";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, month + "%");

            ResultSet rs = pst.executeQuery();
            StringBuilder report = new StringBuilder("Monthly Report for " + month + ":\n\n");

            while (rs.next()) {
                String category = rs.getString("Category");
                double totalAmount = rs.getDouble("TotalAmount");
                report.append(category).append(": ").append(totalAmount).append("\n");
            }

            reportArea.setText(report.toString());
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}